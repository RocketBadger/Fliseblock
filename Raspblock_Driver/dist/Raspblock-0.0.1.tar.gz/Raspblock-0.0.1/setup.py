#从Python发布工具导入"setup"函数
from distutils.core import setup
 
setup(
    name='Raspblock',
    version='0.0.1',
    py_modules = ['Raspblock'],
    author='liusen ',
    author_email='398310535@qq.com',
    url='www.yahboom.com',
    description='Raspblock底层驱动库V0.0.1'
)
